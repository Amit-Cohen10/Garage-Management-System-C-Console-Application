﻿using System;

namespace Ex03.ConsoleUI
{
    static public class Program
    {
        public static void Main()
        {
            GarageMenuApp.RunGarage();
        }
    }
}